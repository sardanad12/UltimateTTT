package com.example.ultimatettt;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Game extends AppCompatActivity {
    int LargeBoard[][] = new int[3][3];

    int board[][] = new int[3][3];
    int turn = 1;
    int imp = 0;
    int kettle =0;
    int winner = 0;
    int x=0;
    int y=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
    }
    try {
        FileInputStream in = openFileInput("board.txt");
        x = in.read();
        y = in.read();
        LargeBoard[0][0] = in.read();
        LargeBoard[0][1] = in.read();
        LargeBoard[0][2] = in.read();
        LargeBoard[1][0] = in.read();
        LargeBoard[1][1] = in.read();
        LargeBoard[1][2] = in.read();
        LargeBoard[2][0] = in.read();
        LargeBoard[2][1] = in.read();
        LargeBoard[2][2] = in.read();

        in.close();
    } catch (
    FileNotFoundException e) {
        e.printStackTrace();
    } catch (
    IOException e) {
        e.printStackTrace();
    }
    TextView win = (TextView)findViewById(R.id.textView2);
        win.setText("Civil War for: "+x+", "+y);
}

    public void toUltimate(View view) {
        try {
            FileOutputStream out = openFileOutput("board.txt", Activity.MODE_PRIVATE);
            out.write(x);//the position just played for
            out.write(y);//the position just played for
            //Print out each ASCII letter in the name
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    out.write(LargeBoard[i][j]);
                }
            }
            out.flush();
            out.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //open main boardgame
        Intent m = new Intent(this, Ultimate.class);
        startActivity(m);
    }
    public void flip(ImageView i) {
        ImageView turnpic = (ImageView) findViewById(R.id.turn);
        if (turn == 1) {
            i.setImageResource(R.drawable.yt);
            turn = 2;
            turnpic.setImageResource(R.drawable.ty);
        } else {
            i.setImageResource(R.drawable.ty);
            turn = 1;
            turnpic.setImageResource(R.drawable.yt);
        }
    }

    public void win() {

        //shows the go back button

        if (board[0][0] == board[0][1] && board[0][0] == board[0][2] && board[0][0] != 0)
            winner = board[0][0];
        else if (board[1][0] == board[1][1] && board[1][0] == board[1][2] && board[1][0] != 0)
            winner = board[1][0];
        else if (board[2][0] == board[2][1] && board[2][0] == board[2][2] && board[2][0] != 0)
            winner = board[2][0];
        else if (board[0][0] == board[1][0] && board[0][0] == board[2][0] && board[0][0] != 0)
            winner = board[0][0];
        else if (board[0][1] == board[1][1] && board[0][1] == board[2][1] && board[0][1] != 0)
            winner = board[0][1];
        else if (board[0][2] == board[1][2] && board[0][2] == board[2][2] && board[0][2] != 0)
            winner = board[0][2];
        else if (board[0][0] == board[1][1] && board[1][1] == board[2][2] && board[1][1] != 0)
            winner = board[1][1];
        else if (board[0][2] == board[1][1] && board[1][1] == board[0][2] && board[0][0] != 0) {
            winner = board[0][2];
        } else if (board[0][0] != 0 && board[0][1] != 0 && board[0][2] != 0 &&
                board[1][0] != 0 && board[1][1] != 0 && board[1][2] != 0 &&
                board[2][0] != 0 && board[2][1] != 0 && board[2][2] != 0) {
            winner = 3;
        }
        if (winner == 1) {
            Toast.makeText(getApplicationContext(), "Captain America Wins", Toast.LENGTH_SHORT).show();
            Button goBack = (Button) findViewById(R.id.goBack);
            goBack.setEnabled(true);
            LargeBoard[x][y]=1;
        } else if (winner == 2) {

            Button goBack = (Button) findViewById(R.id.goBack);
            goBack.setEnabled(true);
            Toast.makeText(getApplicationContext(), "Iron Man Wins", Toast.LENGTH_SHORT).show();
            LargeBoard[x][y]=2;
        } else if (winner == 3) {
            Toast.makeText(getApplicationContext(), "Cat's game", Toast.LENGTH_SHORT).show();
        }

    }

    public void aClick(View view) {
        if (board[0][0] == 0) {
            ImageView i = (ImageView) findViewById(R.id.a);
            board[0][0] = turn;
            flip(i);
        } else {
            Toast.makeText(getApplicationContext(), "Place already taken", Toast.LENGTH_SHORT).show();
        }
        win();
    }

    public void bClick(View view) {
        if (board[0][1] == 0) {
            ImageView i = (ImageView) findViewById(R.id.b);
            board[0][1] = turn;
            flip(i);
        } else {
            Toast.makeText(getApplicationContext(), "Place already taken", Toast.LENGTH_SHORT).show();
        }
        win();
    }

    public void cClick(View view) {
        if (board[0][2] == 0) {
            ImageView i = (ImageView) findViewById(R.id.c);
            board[0][2] = turn;
            flip(i);
        } else {
            Toast.makeText(getApplicationContext(), "Place already taken", Toast.LENGTH_SHORT).show();
        }
        win();
    }

    public void dClick(View view) {
        if (board[1][0] == 0) {
            ImageView i = (ImageView) findViewById(R.id.d);
            board[1][0] = turn;
            flip(i);
        } else {
            Toast.makeText(getApplicationContext(), "Place already taken", Toast.LENGTH_SHORT).show();
        }
        win();
    }

    public void eClick(View view) {
        if (board[1][1] == 0) {
            ImageView i = (ImageView) findViewById(R.id.e);
            board[1][1] = turn;
            flip(i);
        } else {
            Toast.makeText(getApplicationContext(), "Place already taken", Toast.LENGTH_SHORT).show();
        }
        win();
    }

    public void fClick(View view) {
        if (board[1][2] == 0) {
            ImageView i = (ImageView) findViewById(R.id.f);
            board[1][2] = turn;
            flip(i);
        } else {
            Toast.makeText(getApplicationContext(), "Place already taken", Toast.LENGTH_SHORT).show();
        }
        win();
    }

    public void gClick(View view) {
        if (board[2][0] == 0) {
            ImageView i = (ImageView) findViewById(R.id.g);
            board[2][0] = turn;
            flip(i);
        } else {
            Toast.makeText(getApplicationContext(), "Place already taken", Toast.LENGTH_SHORT).show();
        }
        win();
    }

    public void hClick(View view) {
        if (board[2][1] == 0) {
            ImageView i = (ImageView) findViewById(R.id.h);
            board[2][1] = turn;
            flip(i);
        } else {
            Toast.makeText(getApplicationContext(), "Place already taken", Toast.LENGTH_SHORT).show();
        }
        win();
    }

    public void iClick(View view) {
        if (board[2][2] == 0) {
            ImageView i = (ImageView) findViewById(R.id.i);
            board[2][2] = turn;
            flip(i);
        } else {
            Toast.makeText(getApplicationContext(), "Place already taken", Toast.LENGTH_SHORT).show();
        }
        win();
    }

    public void toGame(View view) {
        ImageView a = (ImageView) findViewById(R.id.a);
        a.setImageResource(R.drawable.v);
        ImageView b = (ImageView) findViewById(R.id.b);
        b.setImageResource(R.drawable.v);
        ImageView c = (ImageView) findViewById(R.id.c);
        c.setImageResource(R.drawable.v);
        ImageView d = (ImageView) findViewById(R.id.d);
        d.setImageResource(R.drawable.v);
        ImageView kl = (ImageView) findViewById(R.id.e);
        kl.setImageResource(R.drawable.v);
        ImageView f = (ImageView) findViewById(R.id.f);
        f.setImageResource(R.drawable.v);
        ImageView g = (ImageView) findViewById(R.id.g);
        g.setImageResource(R.drawable.v);
        ImageView h = (ImageView) findViewById(R.id.h);
        h.setImageResource(R.drawable.v);
        ImageView i = (ImageView) findViewById(R.id.i);
        i.setImageResource(R.drawable.v);
        for (int k = 0; k < 3; k++) {
            for (int j = 0; j < 3; j++) {
                board[k][j] = 0;
            }
        }
        Intent n = new Intent(this, MainActivity.class);
        startActivity(n);
        try {
            FileInputStream in = openFileInput("icon.txt");
            imp = in.read();

            in.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        int dawg=  lol(winner, imp);
        try {
            FileOutputStream out = openFileOutput("big.txt", Activity.MODE_PRIVATE);
            //Print out which cat
            out.write(dawg);
            out.flush();
            out.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int lol(int a, int b) {
        if (a==0||a==3){
            int g = 0;
            return g;
        }
        if (a == 1) {
            if (b == 1) {
                kettle = 1;
            } else if (b == 2) {
                kettle = 3;
            } else if (b == 3) {
                kettle = 5;
            } else if (b == 4) {
                kettle = 7;
            } else if (b == 5) {
                kettle = 9;
            } else if (b == 6) {
                kettle = 11;
            } else if (b == 7) {
                kettle = 13;
            } else if (b == 8) {
                kettle = 15;
            } else if (b == 9) {
                kettle = 17;
            }

        } else if (a == 2) {
            if (b == 1) {
                kettle = 2;
            } else if (b == 2) {
                kettle = 4;
            } else if (b == 3) {
                kettle = 6;
            } else if (b == 4) {
                kettle = 8;
            } else if (b == 5) {
                kettle = 10;
            } else if (b == 6) {
                kettle = 12;
            } else if (b == 7) {
                kettle = 14;
            } else if (b == 8) {
                kettle = 16;
            } else if (b == 9) {
                kettle = 18;
            }

        }
        return kettle;

    }

}
