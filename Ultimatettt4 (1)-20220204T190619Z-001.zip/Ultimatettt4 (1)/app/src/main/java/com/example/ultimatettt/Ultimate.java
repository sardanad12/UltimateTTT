package com.example.ultimatettt;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Ultimate extends AppCompatActivity {
    int LargeBoard[][] = new int[3][3];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ultimate);
    }
    //Read in the board
        try {
        FileInputStream in = null;
        try {
            in = openFileInput("board.txt");
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
        try {
            int x = in.read();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        try {
            int y = in.read();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        try {
            LargeBoard[0][0] = in.read();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        try {
            LargeBoard[0][1] = in.read();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        try {
            LargeBoard[0][2] = in.read();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        LargeBoard[1][0] = in.read();
        try {
            LargeBoard[1][1] = in.read();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        try {
            LargeBoard[1][2] = in.read();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        try {
            LargeBoard[2][0] = in.read();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        try {
            LargeBoard[2][1] = in.read();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        try {
            LargeBoard[2][2] = in.read();
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        try {
            in.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    } catch (
    FileNotFoundException e) {
        e.printStackTrace();
    } catch (
    IOException e) {
        e.printStackTrace();
    }

        if (LargeBoard[0][0] == 1) {
        ImageView a = (ImageView) findViewById(R.id.a);
        a.setImageResource(R.drawable.yt);
    } else if (LargeBoard[0][0] == 2) {
        ImageView a = (ImageView) findViewById(R.id.a);
        a.setImageResource(R.drawable.ty);
    }
        if (LargeBoard[0][1] == 1) {
        ImageView a = (ImageView) findViewById(R.id.b);
        a.setImageResource(R.drawable.yt);
    } else if (LargeBoard[0][1] == 2) {
        ImageView a = (ImageView) findViewById(R.id.b);
        a.setImageResource(R.drawable.ty);
    }
        if (LargeBoard[0][2] == 2) {
        ImageView a = (ImageView) findViewById(R.id.c);
        a.setImageResource(R.drawable.yt);
    } else if (LargeBoard[0][2] == 2) {
        ImageView a = (ImageView) findViewById(R.id.c);
        a.setImageResource(R.drawable.ty);
    }
        if (LargeBoard[1][0] == 1) {
        ImageView a = (ImageView) findViewById(R.id.d);
        a.setImageResource(R.drawable.yt);
    } else if (LargeBoard[1][0] == 2) {
        ImageView a = (ImageView) findViewById(R.id.d);
        a.setImageResource(R.drawable.ty);
    }
        if (LargeBoard[1][1] == 1) {
        ImageView a = (ImageView) findViewById(R.id.e);
        a.setImageResource(R.drawable.yt);
    } else if (LargeBoard[1][1] == 2) {
        ImageView a = (ImageView) findViewById(R.id.e);
        a.setImageResource(R.drawable.ty);
    }
        if (LargeBoard[1][2] == 1) {
        ImageView a = (ImageView) findViewById(R.id.f);
        a.setImageResource(R.drawable.yt);
    } else if (LargeBoard[1][2] == 2) {
        ImageView a = (ImageView) findViewById(R.id.f);
        a.setImageResource(R.drawable.ty);
    }
        if (LargeBoard[2][0] == 1) {
        ImageView a = (ImageView) findViewById(R.id.g);
        a.setImageResource(R.drawable.yt);
    } else if (LargeBoard[2][0] == 2) {
        ImageView a = (ImageView) findViewById(R.id.g);
        a.setImageResource(R.drawable.ty);
    }
        if (LargeBoard[2][1] == 1) {
        ImageView a = (ImageView) findViewById(R.id.h);
        a.setImageResource(R.drawable.yt);
    } else if (LargeBoard[2][1] == 2) {
        ImageView a = (ImageView) findViewById(R.id.h);
        a.setImageResource(R.drawable.ty);
    }
        if (LargeBoard[2][2] == 1) {
        ImageView a = (ImageView) findViewById(R.id.i);
        a.setImageResource(R.drawable.yt);
    } else if (LargeBoard[2][2] == 2) {
        ImageView a = (ImageView) findViewById(R.id.i);
        a.setImageResource(R.drawable.ty);
    }
}
    public void newGame(int x, int y) {
        try {
            FileOutputStream out = openFileOutput("board.txt", Activity.MODE_PRIVATE);
            out.write(x);//a number that symbolizes the game starting
            out.write(y);//a number that symbolizes the game starting
            //Print out each ASCII letter in the name
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    out.write(LargeBoard[i][j]);
                }
            }
            out.flush();
            out.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //open game
        Intent m = new Intent(this, Game.class);
        startActivity(m);
    }

    public void aClick(View view) {
        newGame(0, 0);
    }

    public void bClick(View view) {
        newGame(0, 1);
    }

    public void cClick(View view) {
        newGame(0, 2);
    }

    public void dClick(View view) {
        newGame(1, 0);
    }

    public void eClick(View view) {
        newGame(1, 1);
    }

    public void fClick(View view) {
        newGame(1, 2);
    }

    public void gClick(View view) {
        newGame(2, 0);
    }

    public void hClick(View view) {
        newGame(2, 1);
    }

    public void iClick(View view) {
        newGame(2, 2);
    }

}
