package com.example.ultimatettt;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void begin(View view) {
//set up file for next screen
        int LargeBoard[][]=new int[3][3];
        try {
            FileOutputStream out = openFileOutput("board.txt", Activity.MODE_PRIVATE);
            out.write(12);//a number that symbolizes the game starting
            out.write(12);//a number that symbolizes the game starting
//Print out each ASCII letter in the name
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    out.write(LargeBoard[i][j]);
                }
            }
            out.flush();
            out.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

//open game
        Intent m = new Intent(this, Ultimate.class);
        startActivity(m);
    }
    public void backtoInstructions(View view) {
/* Intent i = new Intent(this, Instruction.class);
startActivity(i);
*/
    }
}

